# XS UTOPIA V2 — Platform Entry Build

這份專案包含：

- `index.html`：V2 首頁（平台入口版）
- `commons.html`：公共社區頁，含發文、權限、管理員刪除
- `profile.html`：個人場域頁
- `join.html`：加入平台頁
- `world.html` / `partners.html` / `store.html`：保留擴充頁
- `assets/styles.css`：整體視覺系統
- `assets/app.js`：前端互動、登入模擬、導流、登出、貼文 CRUD（localStorage demo）
- `sql/schema.sql`：Supabase / PostgreSQL 結構與 RLS 權限邏輯

## 已完成的規則

1. 登入後直接導向 `commons.html`
2. 登入後頁面只保留右上角個人介面與登出
3. 已排除探索中心相關導流
4. 會員可發文與刪除自己的貼文
5. 管理員可刪除所有貼文
6. 訪客只能瀏覽公開頁與首頁

## 上線建議

### 靜態 demo
直接部署到 Vercel / Netlify / GitHub Pages 即可預覽。

### 真正會員系統
把 `assets/app.js` 的 localStorage 登入邏輯替換為 Supabase Auth：

- 註冊 / 登入成功後導向 `/commons`
- 取得 session 後讀取 `profiles`
- 依 role 顯示 admin layer
- 貼文、留言、合作資料改走資料庫 API

## 下一步建議

- 接 Supabase Auth 與 real-time feed
- 加入真正的 AI Navigator API
- 建立內容圖片上傳與作品集模組
- 追加商業合作流程與通知中心
