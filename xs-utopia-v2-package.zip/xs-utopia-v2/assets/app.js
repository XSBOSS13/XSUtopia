const STORAGE_KEYS = {
  user: 'xs_utopia_user',
  posts: 'xs_utopia_posts',
  loaded: 'xs_utopia_loaded_once'
};

const defaultPosts = [
  {
    id: 'seed-1',
    title: 'Welcome to XS Commons',
    body: '這裡是平台核心流動區。你可以在此發表創作、提出合作、釋放想法，讓內容、品牌與個體在同一個空間互相連動。',
    type: 'post',
    author: 'XS System',
    role: 'admin',
    createdAt: new Date().toISOString()
  },
  {
    id: 'seed-2',
    title: 'Brand Collaboration Channel Open',
    body: '品牌可在此發佈合作需求，創作者可回應、交流與建立新的策展與商業合作關係。',
    type: 'partner',
    author: 'XS Brand Layer',
    role: 'brand',
    createdAt: new Date(Date.now() - 1000 * 60 * 43).toISOString()
  }
];

const roleLabel = {
  admin: 'Admin',
  brand: 'Brand',
  member: 'Member'
};

function getUser() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEYS.user) || 'null'); } catch { return null; }
}
function setUser(user) { localStorage.setItem(STORAGE_KEYS.user, JSON.stringify(user)); }
function clearUser() { localStorage.removeItem(STORAGE_KEYS.user); }

function getPosts() {
  const raw = localStorage.getItem(STORAGE_KEYS.posts);
  if (!raw) {
    localStorage.setItem(STORAGE_KEYS.posts, JSON.stringify(defaultPosts));
    return [...defaultPosts];
  }
  try { return JSON.parse(raw); } catch { return [...defaultPosts]; }
}
function savePosts(posts) { localStorage.setItem(STORAGE_KEYS.posts, JSON.stringify(posts)); }

function ensureSeed() {
  if (!localStorage.getItem(STORAGE_KEYS.posts)) savePosts(defaultPosts);
}

function updateAuthUI() {
  const user = getUser();
  const guestActions = document.getElementById('guestActions');
  const memberActions = document.getElementById('memberActions');
  const nameNodes = document.querySelectorAll('#headerUserName');
  if (user) {
    guestActions?.classList.add('auth-hidden');
    memberActions?.classList.remove('auth-hidden');
    nameNodes.forEach(node => node.textContent = user.name);
  } else {
    guestActions?.classList.remove('auth-hidden');
    memberActions?.classList.add('auth-hidden');
  }
}

function setupLoading() {
  const loadingScreen = document.getElementById('loadingScreen');
  if (!loadingScreen) return;
  const alreadyLoaded = sessionStorage.getItem(STORAGE_KEYS.loaded);
  const delay = alreadyLoaded ? 180 : 1400;
  setTimeout(() => {
    loadingScreen.classList.add('hidden');
    sessionStorage.setItem(STORAGE_KEYS.loaded, '1');
  }, delay);
}

function setupAuthModal() {
  const modal = document.getElementById('authModal');
  const form = document.getElementById('authForm');
  if (!modal || !form) return;

  document.querySelectorAll('[data-open-auth]').forEach(btn => {
    btn.addEventListener('click', () => {
      modal.classList.add('open');
      modal.setAttribute('aria-hidden', 'false');
    });
  });

  document.querySelectorAll('[data-close-auth]').forEach(btn => {
    btn.addEventListener('click', () => {
      modal.classList.remove('open');
      modal.setAttribute('aria-hidden', 'true');
    });
  });

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = document.getElementById('authName')?.value?.trim() || 'Explorer';
    const email = document.getElementById('authEmail')?.value?.trim() || 'member@xsutopia.world';
    const role = document.getElementById('authRole')?.value || 'member';

    setUser({ name, email, role, joinedAt: new Date().toISOString() });
    updateAuthUI();
    window.location.href = 'commons.html';
  });
}

function setupLogout() {
  document.querySelectorAll('#logoutBtn').forEach(btn => {
    btn.addEventListener('click', () => {
      clearUser();
      window.location.href = 'index.html';
    });
  });
}

function protectCommonsAndProfile() {
  const page = document.body.dataset.page;
  const protectedPages = ['commons', 'profile'];
  if (!protectedPages.includes(page)) return;
  const user = getUser();
  if (!user) window.location.href = 'index.html';
}

function formatTime(isoString) {
  const date = new Date(isoString);
  return `${date.getFullYear()}.${String(date.getMonth() + 1).padStart(2, '0')}.${String(date.getDate()).padStart(2, '0')} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
}

function renderPosts() {
  const stack = document.getElementById('feedStack');
  if (!stack) return;
  const user = getUser();
  const posts = getPosts().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  stack.innerHTML = posts.map(post => {
    const canDelete = user && (user.role === 'admin' || user.name === post.author);
    return `
      <article class="post-card">
        <div class="post-top">
          <div>
            <div class="post-type">${post.type}</div>
            <h3>${escapeHtml(post.title)}</h3>
            <div class="post-meta">
              <span>${escapeHtml(post.author)}</span>
              <span>${roleLabel[post.role] || 'Member'}</span>
              <span>${formatTime(post.createdAt)}</span>
            </div>
          </div>
          ${canDelete ? `<button class="btn ${user.role === 'admin' ? 'btn-danger' : 'btn-ghost'}" data-delete-post="${post.id}">${user.role === 'admin' ? '管理刪除' : '刪除我的貼文'}</button>` : ''}
        </div>
        <p>${escapeHtml(post.body)}</p>
      </article>
    `;
  }).join('');

  stack.querySelectorAll('[data-delete-post]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-delete-post');
      const next = getPosts().filter(post => post.id !== id);
      savePosts(next);
      renderPosts();
      updateStats();
    });
  });
}

function setupComposer() {
  const form = document.getElementById('postForm');
  if (!form) return;
  const user = getUser();
  if (!user) return;
  const composerRole = document.getElementById('composerRole');
  if (composerRole) composerRole.textContent = roleLabel[user.role] || 'Member';

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const title = document.getElementById('postTitle').value.trim();
    const body = document.getElementById('postBody').value.trim();
    const type = document.getElementById('postType').value;
    if (!title || !body) return;
    const posts = getPosts();
    posts.unshift({
      id: `post-${Date.now()}`,
      title,
      body,
      type,
      author: user.name,
      role: user.role,
      createdAt: new Date().toISOString()
    });
    savePosts(posts);
    form.reset();
    renderPosts();
    updateStats();
  });
}

function updateStats() {
  const statPosts = document.getElementById('statPosts');
  if (statPosts) statPosts.textContent = String(getPosts().length);
}

function setupAdminLayer() {
  const adminCard = document.getElementById('adminCard');
  const user = getUser();
  if (!adminCard || !user) return;
  if (user.role === 'admin') adminCard.classList.remove('admin-hidden');
}

function setupProfile() {
  if (document.body.dataset.page !== 'profile') return;
  const user = getUser();
  if (!user) return;
  const name = document.getElementById('profileName');
  const email = document.getElementById('profileEmail');
  const role = document.getElementById('profileRoleTag');
  if (name) name.textContent = user.name;
  if (email) email.textContent = user.email;
  if (role) role.textContent = roleLabel[user.role] || 'Member';
}

function escapeHtml(value) {
  return value
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

document.addEventListener('DOMContentLoaded', () => {
  ensureSeed();
  protectCommonsAndProfile();
  updateAuthUI();
  setupLoading();
  setupAuthModal();
  setupLogout();
  setupComposer();
  renderPosts();
  updateStats();
  setupAdminLayer();
  setupProfile();
});
