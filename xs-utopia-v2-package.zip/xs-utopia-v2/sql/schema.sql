-- XS UTOPIA V2
-- 建議資料庫：Supabase / PostgreSQL
-- 重構重點：
-- 1. 登入後直接導向 commons
-- 2. 所有頁面不再出現登入/註冊連結，只保留 profile + logout
-- 3. 移除探索中心相關頁面與欄位
-- 4. 權限：visitor / member / brand / admin

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key default gen_random_uuid(),
  auth_user_id uuid unique,
  username text not null,
  email text unique not null,
  role text not null default 'member' check (role in ('visitor', 'member', 'brand', 'admin')),
  bio text,
  avatar_url text,
  status text not null default 'active' check (status in ('active', 'suspended', 'archived')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  author_profile_id uuid references public.profiles(id) on delete cascade,
  type text not null default 'post' check (type in ('post', 'project', 'partner', 'ecosystem')),
  title text not null,
  body text not null,
  visibility text not null default 'public' check (visibility in ('public', 'members', 'private')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  author_profile_id uuid not null references public.profiles(id) on delete cascade,
  body text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.partnership_requests (
  id uuid primary key default gen_random_uuid(),
  creator_profile_id uuid references public.profiles(id) on delete set null,
  brand_profile_id uuid references public.profiles(id) on delete set null,
  title text not null,
  brief text not null,
  budget_min numeric(12,2),
  budget_max numeric(12,2),
  status text not null default 'open' check (status in ('open', 'negotiating', 'closed', 'archived')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.ecosystem_entries (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid references public.profiles(id) on delete set null,
  title text not null,
  content text not null,
  category text not null default 'general',
  created_at timestamptz not null default now()
);

create table if not exists public.system_settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);

insert into public.system_settings(key, value)
values
  ('post_login_redirect', '{"path": "/commons"}'),
  ('show_guest_auth_links', 'false'::jsonb),
  ('deprecated_buttons', '["探索中心"]'::jsonb)
on conflict (key) do update set value = excluded.value, updated_at = now();

create index if not exists idx_profiles_role on public.profiles(role);
create index if not exists idx_posts_author on public.posts(author_profile_id);
create index if not exists idx_posts_created_at on public.posts(created_at desc);
create index if not exists idx_comments_post on public.comments(post_id);
create index if not exists idx_partnership_status on public.partnership_requests(status);

create or replace function public.handle_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_profiles_updated_at on public.profiles;
create trigger trg_profiles_updated_at
before update on public.profiles
for each row execute function public.handle_updated_at();

drop trigger if exists trg_posts_updated_at on public.posts;
create trigger trg_posts_updated_at
before update on public.posts
for each row execute function public.handle_updated_at();

drop trigger if exists trg_comments_updated_at on public.comments;
create trigger trg_comments_updated_at
before update on public.comments
for each row execute function public.handle_updated_at();

drop trigger if exists trg_partnership_requests_updated_at on public.partnership_requests;
create trigger trg_partnership_requests_updated_at
before update on public.partnership_requests
for each row execute function public.handle_updated_at();

-- Row Level Security
alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.comments enable row level security;
alter table public.partnership_requests enable row level security;
alter table public.ecosystem_entries enable row level security;

-- profiles: everyone can read active profiles; users can edit self; admin can edit all
create policy "profiles_select_active"
on public.profiles for select
using (status = 'active');

create policy "profiles_update_self_or_admin"
on public.profiles for update
using (
  auth.uid() = auth_user_id
  or exists (
    select 1 from public.profiles p
    where p.auth_user_id = auth.uid() and p.role = 'admin'
  )
);

create policy "profiles_insert_self"
on public.profiles for insert
with check (auth.uid() = auth_user_id);

-- posts: visitors can read public; members/brands/admin can insert; authors can delete own; admin can delete all
create policy "posts_select_public"
on public.posts for select
using (
  visibility = 'public'
  or exists (
    select 1 from public.profiles p
    where p.auth_user_id = auth.uid() and p.role in ('member', 'brand', 'admin')
  )
);

create policy "posts_insert_member_brand_admin"
on public.posts for insert
with check (
  exists (
    select 1 from public.profiles p
    where p.id = author_profile_id and p.auth_user_id = auth.uid() and p.role in ('member', 'brand', 'admin')
  )
);

create policy "posts_delete_owner_or_admin"
on public.posts for delete
using (
  exists (
    select 1 from public.profiles p
    where p.id = author_profile_id and p.auth_user_id = auth.uid()
  )
  or exists (
    select 1 from public.profiles admin_p
    where admin_p.auth_user_id = auth.uid() and admin_p.role = 'admin'
  )
);

create policy "posts_update_owner_or_admin"
on public.posts for update
using (
  exists (
    select 1 from public.profiles p
    where p.id = author_profile_id and p.auth_user_id = auth.uid()
  )
  or exists (
    select 1 from public.profiles admin_p
    where admin_p.auth_user_id = auth.uid() and admin_p.role = 'admin'
  )
);

-- comments: members/brands/admin can comment; author can delete own; admin can delete all
create policy "comments_select_all"
on public.comments for select
using (true);

create policy "comments_insert_member_brand_admin"
on public.comments for insert
with check (
  exists (
    select 1 from public.profiles p
    where p.id = author_profile_id and p.auth_user_id = auth.uid() and p.role in ('member', 'brand', 'admin')
  )
);

create policy "comments_delete_owner_or_admin"
on public.comments for delete
using (
  exists (
    select 1 from public.profiles p
    where p.id = author_profile_id and p.auth_user_id = auth.uid()
  )
  or exists (
    select 1 from public.profiles admin_p
    where admin_p.auth_user_id = auth.uid() and admin_p.role = 'admin'
  )
);

-- partnership_requests: only logged-in brand/member/admin can create; only related parties/admin can update/delete
create policy "partnership_select_logged_in"
on public.partnership_requests for select
using (auth.uid() is not null);

create policy "partnership_insert_logged_in"
on public.partnership_requests for insert
with check (auth.uid() is not null);

create policy "partnership_update_related_or_admin"
on public.partnership_requests for update
using (
  exists (
    select 1
    from public.profiles p
    where p.auth_user_id = auth.uid()
      and (p.id = creator_profile_id or p.id = brand_profile_id or p.role = 'admin')
  )
);

-- ecosystem_entries
create policy "ecosystem_select_public"
on public.ecosystem_entries for select
using (true);

create policy "ecosystem_insert_logged_in"
on public.ecosystem_entries for insert
with check (auth.uid() is not null);

-- Optional seed admin
-- insert into public.profiles(auth_user_id, username, email, role)
-- values ('YOUR_AUTH_UID', 'Admin', 'admin@xsutopia.world', 'admin');

-- Frontend auth flow recommendation:
-- after sign-in success => router.push('/commons')
-- header render rule:
-- if session exists => show profile + logout
-- else => show login + register only on public entry pages
-- remove any old links/buttons named 探索中心 from menus and templates
